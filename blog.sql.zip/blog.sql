-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2017 年 08 月 16 日 00:13
-- 服务器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 数据库: `blog`
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `blog_blog`
-- 

CREATE TABLE `blog_blog` (
  `id` mediumint(8) NOT NULL auto_increment,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- 导出表中的数据 `blog_blog`
-- 

INSERT INTO `blog_blog` VALUES (1, '第一次', '第一条博文', '2017-08-15 17:20:40');
INSERT INTO `blog_blog` VALUES (2, '第二条', '第二条', '2017-08-15 17:21:36');
INSERT INTO `blog_blog` VALUES (3, '第三条', '第三条', '2017-08-15 17:23:21');
INSERT INTO `blog_blog` VALUES (4, '第四条', '第四条博文', '2017-08-15 17:56:22');
INSERT INTO `blog_blog` VALUES (5, '第五条', '第五条博文', '2017-08-15 18:19:53');

-- --------------------------------------------------------

-- 
-- 表的结构 `blog_skin`
-- 

CREATE TABLE `blog_skin` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `small_bg` varchar(200) NOT NULL,
  `big_bg` varchar(200) NOT NULL,
  `bg_color` varchar(200) NOT NULL,
  `bg_text` varchar(200) NOT NULL,
  `bg_flag` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- 导出表中的数据 `blog_skin`
-- 

INSERT INTO `blog_skin` VALUES (1, 'small_bg1.png', 'bg1.jpg', '#E7E9E8', '皮肤1', 0);
INSERT INTO `blog_skin` VALUES (2, 'small_bg2.png', 'bg2.jpg', '#ECF0FC', '皮肤2', 0);
INSERT INTO `blog_skin` VALUES (3, 'small_bg3.png', 'bg3.jpg', '#E2E2E2', '皮肤3', 0);
INSERT INTO `blog_skin` VALUES (4, 'small_bg4.png', 'bg4.jpg', '#FFFFFF', '皮肤4', 0);
INSERT INTO `blog_skin` VALUES (5, 'small_bg5.png', 'bg5.jpg', '#F3F3F3', '皮肤5', 0);
INSERT INTO `blog_skin` VALUES (6, 'small_bg6.png', 'bg6.jpg', '#EBDEBE', '皮肤6', 0);

-- --------------------------------------------------------

-- 
-- 表的结构 `blog_user`
-- 

CREATE TABLE `blog_user` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `user` varchar(20) NOT NULL,
  `pass` char(40) NOT NULL,
  `ques` varchar(200) NOT NULL,
  `ans` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `birthday` date NOT NULL,
  `ps` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- 导出表中的数据 `blog_user`
-- 

INSERT INTO `blog_user` VALUES (1, '123333', 'd8882c795f2da1447017f8ec31cb84a1b76e4006', '1', '1212', '34324332@qq.com', '1962-03-15', '');
INSERT INTO `blog_user` VALUES (2, 'zhangqian', '961a01ade5449c52781317513e5803163d5b67be', '1', '酸菜鱼', '3443254@qq.com', '1962-04-11', '无');
INSERT INTO `blog_user` VALUES (3, 'zhangqian1', '4be30d9814c6d4e9800e0d2ea9ec9fb00efa887b', '1', '哈哈', '1237884@qq.com', '1962-03-11', '无');
INSERT INTO `blog_user` VALUES (4, 'zhangqian1', '4be30d9814c6d4e9800e0d2ea9ec9fb00efa887b', '1', '哈哈', '1237884@qq.com', '1962-03-11', '无');
INSERT INTO `blog_user` VALUES (5, 'zhangqian2', '4be30d9814c6d4e9800e0d2ea9ec9fb00efa887b', '2', 'hua', '1235325@qq.com', '1961-02-08', '');
INSERT INTO `blog_user` VALUES (6, 'zhangqian3', '4be30d9814c6d4e9800e0d2ea9ec9fb00efa887b', '1', '24135', '14516@qq.com', '1963-03-28', '无');
INSERT INTO `blog_user` VALUES (7, 'zhangqian5', '4be30d9814c6d4e9800e0d2ea9ec9fb00efa887b', '2', 'hu', '24526@qq.com', '1953-04-13', '');
INSERT INTO `blog_user` VALUES (8, '4361', '4be30d9814c6d4e9800e0d2ea9ec9fb00efa887b', '1', '342352', '41t43@163.com', '1962-02-13', '');
